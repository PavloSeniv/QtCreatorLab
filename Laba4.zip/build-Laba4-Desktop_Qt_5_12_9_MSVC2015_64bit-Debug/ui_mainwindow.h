/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *mainLbl;
    QPushButton *noBtn;
    QPushButton *yesBtn;
    QCheckBox *cheatChkBox;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 596);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        MainWindow->setPalette(palette);
        MainWindow->setCursor(QCursor(Qt::PointingHandCursor));
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: #000;"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        mainLbl = new QLabel(centralwidget);
        mainLbl->setObjectName(QString::fromUtf8("mainLbl"));
        mainLbl->setGeometry(QRect(0, 0, 801, 61));
        mainLbl->setToolTipDuration(1);
        mainLbl->setStyleSheet(QString::fromUtf8("background-color: #9c27b0;\n"
"color: #000000;\n"
"border-radius: 0px;\n"
"text-align: center;\n"
"\n"
"font: 14pt \"Courier New\";"));
        mainLbl->setTextFormat(Qt::AutoText);
        mainLbl->setAlignment(Qt::AlignCenter);
        noBtn = new QPushButton(centralwidget);
        noBtn->setObjectName(QString::fromUtf8("noBtn"));
        noBtn->setGeometry(QRect(50, 290, 271, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Courier New"));
        font.setPointSize(14);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        noBtn->setFont(font);
        noBtn->setAutoFillBackground(false);
        noBtn->setStyleSheet(QString::fromUtf8("background-color: #f44336;\n"
"color: #000000;\n"
"border:none;\n"
"border-radius: 4px;\n"
"font: 14pt \"Courier New\";"));
        yesBtn = new QPushButton(centralwidget);
        yesBtn->setObjectName(QString::fromUtf8("yesBtn"));
        yesBtn->setGeometry(QRect(480, 290, 271, 51));
        yesBtn->setFont(font);
        yesBtn->setAutoFillBackground(false);
        yesBtn->setStyleSheet(QString::fromUtf8("background-color: #69f0ae;\n"
"color: #000000;\n"
"border:none;\n"
"border-radius: 4px;\n"
"font: 14pt \"Courier New\";"));
        cheatChkBox = new QCheckBox(centralwidget);
        cheatChkBox->setObjectName(QString::fromUtf8("cheatChkBox"));
        cheatChkBox->setGeometry(QRect(50, 110, 271, 51));
        cheatChkBox->setMouseTracking(true);
        cheatChkBox->setTabletTracking(false);
        cheatChkBox->setLayoutDirection(Qt::LeftToRight);
        cheatChkBox->setAutoFillBackground(false);
        cheatChkBox->setStyleSheet(QString::fromUtf8("color: white;\n"
"border:none;\n"
"font: 14pt \"Courier New\";\n"
" "));
        cheatChkBox->setAutoExclusive(false);
        cheatChkBox->setTristate(false);
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Laba4", nullptr));
        mainLbl->setText(QApplication::translate("MainWindow", "\320\221\320\260\320\266\320\260\321\224\321\202\320\265 \320\262\321\226\320\264\320\274\321\226\320\275\320\275\320\276?", nullptr));
        noBtn->setText(QApplication::translate("MainWindow", "\320\235\321\226", nullptr));
        yesBtn->setText(QApplication::translate("MainWindow", "\320\242\320\260\320\272", nullptr));
        cheatChkBox->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\260\321\206\321\216\320\262\320\260\320\262 \320\262\320\265\321\201\321\214 \321\201\320\265\320\274\320\265\321\201\321\202\321\200", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
