/********************************************************************************
** Form generated from reading UI file 'pif.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PIF_H
#define UI_PIF_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_pif
{
public:
    QLabel *label;
    QSpinBox *leg1;
    QSpinBox *leg2;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *clcBtn;

    void setupUi(QDialog *pif)
    {
        if (pif->objectName().isEmpty())
            pif->setObjectName(QString::fromUtf8("pif"));
        pif->resize(552, 361);
        label = new QLabel(pif);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 10, 231, 61));
        QFont font;
        font.setPointSize(14);
        label->setFont(font);
        leg1 = new QSpinBox(pif);
        leg1->setObjectName(QString::fromUtf8("leg1"));
        leg1->setGeometry(QRect(420, 80, 91, 41));
        leg1->setFont(font);
        leg2 = new QSpinBox(pif);
        leg2->setObjectName(QString::fromUtf8("leg2"));
        leg2->setGeometry(QRect(420, 140, 91, 41));
        leg2->setFont(font);
        label_2 = new QLabel(pif);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 80, 111, 31));
        label_2->setFont(font);
        label_3 = new QLabel(pif);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 130, 101, 51));
        label_3->setFont(font);
        clcBtn = new QPushButton(pif);
        clcBtn->setObjectName(QString::fromUtf8("clcBtn"));
        clcBtn->setGeometry(QRect(10, 280, 121, 61));
        clcBtn->setFont(font);
        clcBtn->setStyleSheet(QString::fromUtf8("background-color:rgb(0, 255, 0);\n"
"color:rgb(0, 0, 0);"));

        retranslateUi(pif);

        QMetaObject::connectSlotsByName(pif);
    } // setupUi

    void retranslateUi(QDialog *pif)
    {
        pif->setWindowTitle(QApplication::translate("pif", "Task1", nullptr));
        label->setText(QApplication::translate("pif", "\320\227\320\275\320\260\321\205\320\276\320\264\320\266\320\265\320\275\320\275\321\217 \320\263\321\226\320\277\320\276\321\202\320\265\320\275\321\203\320\267\320\270", nullptr));
        label_2->setText(QApplication::translate("pif", "\320\232\320\260\321\202\320\265\321\202 \320\220", nullptr));
        label_3->setText(QApplication::translate("pif", "\320\232\320\260\321\202\320\265\321\202 B", nullptr));
        clcBtn->setText(QApplication::translate("pif", "\320\236\320\261\321\207\320\270\321\201\320\273\320\265\320\275\320\275\321\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class pif: public Ui_pif {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PIF_H
