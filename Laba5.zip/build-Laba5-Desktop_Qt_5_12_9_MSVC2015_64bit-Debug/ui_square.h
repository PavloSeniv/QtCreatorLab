/********************************************************************************
** Form generated from reading UI file 'square.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SQUARE_H
#define UI_SQUARE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_square
{
public:
    QPushButton *calcBtn;
    QDoubleSpinBox *sideA;
    QDoubleSpinBox *sideB;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QRadioButton *sqrBtn;
    QRadioButton *perimBtn;

    void setupUi(QDialog *square)
    {
        if (square->objectName().isEmpty())
            square->setObjectName(QString::fromUtf8("square"));
        square->resize(543, 421);
        calcBtn = new QPushButton(square);
        calcBtn->setObjectName(QString::fromUtf8("calcBtn"));
        calcBtn->setGeometry(QRect(10, 340, 161, 61));
        QFont font;
        font.setPointSize(14);
        calcBtn->setFont(font);
        calcBtn->setStyleSheet(QString::fromUtf8("background-color:rgb(0, 255, 0);\n"
"color:rgb(0, 0, 0);"));
        sideA = new QDoubleSpinBox(square);
        sideA->setObjectName(QString::fromUtf8("sideA"));
        sideA->setGeometry(QRect(440, 110, 91, 41));
        sideA->setFont(font);
        sideB = new QDoubleSpinBox(square);
        sideB->setObjectName(QString::fromUtf8("sideB"));
        sideB->setGeometry(QRect(440, 50, 91, 41));
        sideB->setFont(font);
        label = new QLabel(square);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 60, 101, 31));
        label->setFont(font);
        label_2 = new QLabel(square);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 110, 101, 41));
        label_2->setFont(font);
        label_3 = new QLabel(square);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 0, 181, 51));
        label_3->setFont(font);
        sqrBtn = new QRadioButton(square);
        sqrBtn->setObjectName(QString::fromUtf8("sqrBtn"));
        sqrBtn->setGeometry(QRect(20, 270, 101, 31));
        sqrBtn->setFont(font);
        perimBtn = new QRadioButton(square);
        perimBtn->setObjectName(QString::fromUtf8("perimBtn"));
        perimBtn->setGeometry(QRect(20, 220, 121, 41));
        QFont font1;
        font1.setPointSize(12);
        perimBtn->setFont(font1);

        retranslateUi(square);

        QMetaObject::connectSlotsByName(square);
    } // setupUi

    void retranslateUi(QDialog *square)
    {
        square->setWindowTitle(QApplication::translate("square", "Task2", nullptr));
        calcBtn->setText(QApplication::translate("square", "\320\236\320\261\321\207\320\270\321\201\320\273\320\265\320\275\320\275\321\217", nullptr));
        label->setText(QApplication::translate("square", "\320\241\321\202\320\276\321\200\320\276\320\275\320\260 \320\220", nullptr));
        label_2->setText(QApplication::translate("square", "\320\241\321\202\320\276\321\200\320\276\320\275\320\260 B", nullptr));
        label_3->setText(QApplication::translate("square", "\320\237\320\273\320\276\321\211\320\260 \321\202\320\260 \320\277\320\265\321\200\320\270\320\274\320\265\321\202\321\200", nullptr));
        sqrBtn->setText(QApplication::translate("square", "\320\237\320\273\320\276\321\211\320\260", nullptr));
        perimBtn->setText(QApplication::translate("square", "\320\237\320\265\321\200\320\270\320\274\320\265\321\202\321\200", nullptr));
    } // retranslateUi

};

namespace Ui {
    class square: public Ui_square {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SQUARE_H
