/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_4;
    QLabel *label;
    QPushButton *pushButton_5;
    QPushButton *pushButton_3;
    QTimeEdit *timeEdit;
    QLabel *label_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLabel *label_4;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(841, 520);
        MainWindow->setMinimumSize(QSize(500, 356));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(14);
        MainWindow->setFont(font);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("color: rgb(98, 98, 98);\n"
""));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 10, 161, 61));
        QFont font1;
        font1.setPointSize(14);
        font1.setUnderline(false);
        font1.setStrikeOut(false);
        pushButton_4->setFont(font1);
        pushButton_4->setStyleSheet(QString::fromUtf8("  color: #fff; \n"
"  text-decoration: none; \n"
"  user-select: none; \n"
"  background: rgb(0,128,0); \n"
"  padding: .7em 1.5em; \n"
"  outline: none;"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(250, 150, 321, 141));
        QFont font2;
        font2.setFamily(QString::fromUtf8("MS Serif"));
        font2.setPointSize(20);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        font2.setStyleStrategy(QFont::PreferDefault);
        label->setFont(font2);
        label->setStyleSheet(QString::fromUtf8("font: 20pt \"MS Serif\";\n"
"color: rgb(0,0,0);"));
        label->setAlignment(Qt::AlignCenter);
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(670, 10, 161, 61));
        pushButton_5->setFont(font1);
        pushButton_5->setStyleSheet(QString::fromUtf8("  color: #fff; \n"
"  text-decoration: none; \n"
"  user-select: none; \n"
"  background: rgb(0,128,0); \n"
"  padding: .7em 1.5em; \n"
"  outline: none;"));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(10, 450, 161, 61));
        pushButton_3->setFont(font1);
        pushButton_3->setStyleSheet(QString::fromUtf8("  color: #fff; \n"
"  text-decoration: none; \n"
"  user-select: none; \n"
"  background: rgb(0,128,0); \n"
"  padding: .7em 1.5em; \n"
"  outline: none;"));
        timeEdit = new QTimeEdit(centralwidget);
        timeEdit->setObjectName(QString::fromUtf8("timeEdit"));
        timeEdit->setGeometry(QRect(670, 320, 161, 41));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(668, 270, 151, 43));
        QFont font3;
        font3.setFamily(QString::fromUtf8("MS Serif"));
        font3.setPointSize(20);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        label_3->setFont(font3);
        label_3->setStyleSheet(QString::fromUtf8("font: 20pt \"MS Serif\";\n"
"color: rgb(0,0,0);"));
        label_3->setAlignment(Qt::AlignCenter);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(670, 370, 161, 61));
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QString::fromUtf8("  color: #fff; \n"
"  text-decoration: none; \n"
"  user-select: none; \n"
"  background: rgb(0,128,0); \n"
"  padding: .7em 1.5em; \n"
"  outline: none;"));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(670, 450, 161, 61));
        pushButton_2->setFont(font1);
        pushButton_2->setStyleSheet(QString::fromUtf8("  color: #fff; \n"
"  text-decoration: none; \n"
"  user-select: none; \n"
"  background: rgb(0,128,0); \n"
"  padding: .7em 1.5em; \n"
"  outline: none;"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 390, 161, 41));
        label_2->setStyleSheet(QString::fromUtf8("font: 20pt \"MS Serif\";\n"
"color: rgb(0,0,0);"));
        label_2->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(550, 80, 281, 61));
        label_4->setStyleSheet(QString::fromUtf8("font: 20pt \"MS Serif\";\n"
"color: rgb(0,0,0);"));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\320\223\320\276\320\264\320\270\320\275\320\275\320\270\320\272", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "\320\237\321\226\320\264\321\201\320\262\321\226\321\202\320\272\320\260 ON", nullptr));
        label->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "\320\224\320\260\321\202\320\260", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "\320\241\320\265\320\272\321\203\320\275\320\264\320\276\320\274\321\226\321\200", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "\320\221\321\203\320\264\320\270\320\273\321\214\320\275\320\270\320\272", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "OFF", nullptr));
        label_2->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
