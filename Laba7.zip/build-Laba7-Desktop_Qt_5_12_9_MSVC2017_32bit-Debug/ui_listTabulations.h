/********************************************************************************
** Form generated from reading UI file 'listTabulations.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LISTTABULATIONS_H
#define UI_LISTTABULATIONS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_table
{
public:
    QWidget *centralwidget;
    QTableWidget *tableWidget;
    QPushButton *pushButton_2;

    void setupUi(QMainWindow *table)
    {
        if (table->objectName().isEmpty())
            table->setObjectName(QString::fromUtf8("table"));
        table->resize(550, 448);
        centralwidget = new QWidget(table);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("background-color:qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:0.05 rgba(14, 8, 73, 255), stop:0.36 rgba(28, 17, 145, 255), stop:0.6 rgba(126, 14, 81, 255), stop:0.75 rgba(234, 11, 11, 255), stop:0.79 rgba(244, 70, 5, 255), stop:0.86 rgba(255, 136, 0, 255), stop:0.935 rgba(239, 236, 55, 255))"));
        tableWidget = new QTableWidget(centralwidget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(20, 10, 511, 361));
        QFont font;
        font.setFamily(QString::fromUtf8("Century"));
        font.setPointSize(14);
        font.setItalic(false);
        font.setUnderline(false);
        font.setStrikeOut(false);
        tableWidget->setFont(font);
        tableWidget->setStyleSheet(QString::fromUtf8("color: rgb(255, 170, 0); \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 390, 511, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Century"));
        font1.setPointSize(11);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        font1.setStrikeOut(false);
        pushButton_2->setFont(font1);
        pushButton_2->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        table->setCentralWidget(centralwidget);

        retranslateUi(table);

        QMetaObject::connectSlotsByName(table);
    } // setupUi

    void retranslateUi(QMainWindow *table)
    {
        table->setWindowTitle(QApplication::translate("table", "Table", nullptr));
        pushButton_2->setText(QApplication::translate("table", "\320\235\320\260 \320\263\320\276\320\273\320\276\320\262\320\275\321\203", nullptr));
    } // retranslateUi

};

namespace Ui {
    class table: public Ui_table {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LISTTABULATIONS_H
