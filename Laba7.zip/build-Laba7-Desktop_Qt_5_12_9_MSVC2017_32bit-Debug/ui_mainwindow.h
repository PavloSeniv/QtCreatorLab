/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QDoubleSpinBox *doubleSpinBox_firstStep;
    QDoubleSpinBox *doubleSpinBox_lastStep;
    QDoubleSpinBox *doubleSpinBox_step;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(701, 315);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(0, 0, 0, 255), stop:0.05 rgba(14, 8, 73, 255), stop:0.36 rgba(28, 17, 145, 255), stop:0.6 rgba(126, 14, 81, 255), stop:0.75 rgba(234, 11, 11, 255), stop:0.79 rgba(244, 70, 5, 255), stop:0.86 rgba(255, 136, 0, 255), stop:0.935 rgba(239, 236, 55, 255))\n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("background-color:qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:0.05 rgba(14, 8, 73, 255), stop:0.36 rgba(28, 17, 145, 255), stop:0.6 rgba(126, 14, 81, 255), stop:0.75 rgba(234, 11, 11, 255), stop:0.79 rgba(244, 70, 5, 255), stop:0.86 rgba(255, 136, 0, 255), stop:0.935 rgba(239, 236, 55, 255))"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 701, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Century"));
        font.setPointSize(14);
        font.setItalic(false);
        font.setUnderline(false);
        font.setStrikeOut(false);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        label->setAlignment(Qt::AlignCenter);
        doubleSpinBox_firstStep = new QDoubleSpinBox(centralwidget);
        doubleSpinBox_firstStep->setObjectName(QString::fromUtf8("doubleSpinBox_firstStep"));
        doubleSpinBox_firstStep->setGeometry(QRect(120, 60, 101, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Cascadia Mono"));
        font1.setPointSize(14);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setStrikeOut(false);
        doubleSpinBox_firstStep->setFont(font1);
        doubleSpinBox_firstStep->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        doubleSpinBox_firstStep->setAlignment(Qt::AlignCenter);
        doubleSpinBox_lastStep = new QDoubleSpinBox(centralwidget);
        doubleSpinBox_lastStep->setObjectName(QString::fromUtf8("doubleSpinBox_lastStep"));
        doubleSpinBox_lastStep->setGeometry(QRect(350, 60, 101, 51));
        doubleSpinBox_lastStep->setFont(font1);
        doubleSpinBox_lastStep->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        doubleSpinBox_lastStep->setAlignment(Qt::AlignCenter);
        doubleSpinBox_step = new QDoubleSpinBox(centralwidget);
        doubleSpinBox_step->setObjectName(QString::fromUtf8("doubleSpinBox_step"));
        doubleSpinBox_step->setGeometry(QRect(560, 60, 111, 51));
        doubleSpinBox_step->setFont(font1);
        doubleSpinBox_step->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        doubleSpinBox_step->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 60, 101, 51));
        label_3->setFont(font);
        label_3->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        label_3->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(270, 60, 81, 51));
        label_4->setFont(font);
        label_4->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        label_4->setAlignment(Qt::AlignCenter);
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(490, 60, 71, 51));
        label_5->setFont(font);
        label_5->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        label_5->setAlignment(Qt::AlignCenter);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(390, 240, 281, 61));
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 240, 281, 61));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("color: #fff; \n"
"text-decoration: none; \n"
"user-select: cursor;\n"
"background:#14141a;\n"
"outline: none; \n"
"border: 1px solid #e5c182;\n"
"border-radius:5px"));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Laba7", nullptr));
        label->setText(QApplication::translate("MainWindow", "\320\244\321\203\320\275\320\272\321\206\321\226\321\217 tg(x)", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "\320\237\320\276\321\207\320\260\321\202\320\276\320\272", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "\320\232\321\226\320\275\320\265\321\206\321\214", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "\320\232\321\200\320\276\320\272", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "\320\227\320\260\320\277\320\270\321\201 \321\203 \321\204\320\260\320\271\320\273", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "\320\224\320\260\320\275\321\226 \320\262 \321\202\320\260\320\261\320\273\320\270\321\206\321\226", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
